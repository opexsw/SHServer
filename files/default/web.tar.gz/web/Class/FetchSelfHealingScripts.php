<?php
use GitElephant\Repository;
use GitElephant\Command\MainCommand;

class FetchSelfHealingScripts
{

	function fetchHealingScript($scriptpath){
  		$fileContents = file_get_contents($scriptpath, true);
  		return $fileContents;
  	}
	
}