<?php

Class Constants{

	const REPOSITORY_URL = "https://zeeshan21:zeeshan10@github.com/opexsw/hscripts.git";
	#const REPOSITORY_URL = "https://c5229478:puja123@github.wdf.sap.corp/c5229478/selfhealingscripts.git";
	#const REPO_PATH      = "/usr/local/SHS/selfhealingscripts/";
	const REPO_PATH      = "/var/www/html/SHS/repository/";
	const REPO_NAME      = "hscripts";
	#const REPO_NAME      = "selfhealingscripts";
}
?>

