<?php
use GitElephant\Repository;
use GitElephant\Command\MainCommand;

class CloneSelfHealingScripts
{
	function cloneGitRepo(){ 
			
      		/*$fullPath = Constants::REPOSITORY_URL; //give exact path of the repository having all the selfHealing scripts.   
		    $path 	  = Constants::REPO_PATH; //give the path to keep all the cloned scripts.*/
		   	$ini_array = parse_ini_file($_SERVER["DOCUMENT_ROOT"].'/SHS/conf/healingscriptconf.ini');
			$fullPath  = $ini_array["REPOSITORY_URL"];
			$path 	   = $ini_array["REPO_PATH"];
	      	$repo 	   = new Repository($path);
	      	try{
	      		$repo->init(); // init  
	      		$repo->addGlobalConfig("http.sslverify","false");
	      		$repo->cloneFrom($fullPath);
	      	}
	      	catch(Exception $e)
	      	{
	      		file_put_contents($_SERVER["DOCUMENT_ROOT"].'/SHS/logs/shslog.log', "cloneGitRepo exception $e", FILE_APPEND);
	      	}
  	}

  	function pullGitRepo(){

  			/*$repoName = Constants::REPO_NAME;
  			$path 	  = Constants::REPO_PATH;*/
  			$ini_array = parse_ini_file($_SERVER["DOCUMENT_ROOT"].'/SHS/conf/healingscriptconf.ini');
			$repoName  = $ini_array["REPO_NAME"];
			$path 	   = $ini_array["REPO_PATH"];
  			$repoPath  = $path.$repoName;
		  	if(file_exists($repoPath)){
		      	$repo = new Repository($repoPath);
		      	try{
		      		$repo->init(); // init
		      		$repo->addGlobalConfig("http.sslverify","false");
		      		$repo->pull('origin','master');
		      	}
		      	catch(Exception $e)
	      		{
	      			file_put_contents($_SERVER["DOCUMENT_ROOT"].'/SHS/logs/shslog.log', "pullGitRepo exception $e", FILE_APPEND);
	      		}
	      	} else {
	      		$this->cloneGitRepo();
	      	}

  	}
}
