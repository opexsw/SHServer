<?php
use GuzzleHttp\Client;

class DataCollectorClient
{
	function collectAPIData(){
		try{
			$client = new Client(['base_uri' => 'http://localhost:3000/']);
			$response = $client->request('GET', 'nagiosservice');
		}catch (ClientException $e) {
 		   echo Psr7\str($e->getRequest());
    		if ($e->hasResponse()) {
        		echo Psr7\str($e->getResponse());
    		}
		}
		/*$responseJson = json_decode($response->getBody());
		$key = "services";
		//$valueName = "hostname";
		$valueName = "service";
		$valueArray = $responseJson->$key;
		foreach ($valueArray as $value) {
			print_r($value->$valueName);
		}*/
		return $response;
	}

}
