<?php header('Access-Control-Allow-Origin: *');
use GitElephant\Repository;
use GitElephant\Command\PullCommand;

$app->get('/', function(){        
});

$app->get('/services', function(){
	$testClient = new DataCollectorClient();
	$response = $testClient->collectAPIData();
	return $response;        
});
// To get the contents of a selfhealingscript by filename.
/*$app->get('/selfhealingscript/{scriptname}', function($request, $response, $args){
    $getScripts = new FetchSelfHealingScripts();
    $scripts 	= $getScripts->fetchHealingScript($args['scriptname']);
    return $scripts;
});*/

// To get the contents of a selfhealingscript by filepath
// e.g. http://localhost:8000/selfhealingscript?filepath=/home/zeeshan/SlimPHP/composer.json
$app->get('/selfhealingscript', function($request, $response, $args){
    $getScripts = new FetchSelfHealingScripts();
    $filepath = $request->getParam('filepath');
    $scripts 	= $getScripts->fetchHealingScript($filepath);
    return $scripts;
});

// To get the latest code from Github.
$app->get('/getlatestscripts', function($request, $response, $args){
    $getLatestScripts = new CloneSelfHealingScripts();
    $scripts 	= $getLatestScripts->pullGitRepo();
});

?>
