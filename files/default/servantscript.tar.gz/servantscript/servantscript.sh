
 # @name Servant Script
 # @description Script to trigger the notification on serf Engine
 # @author Zeeshan
 
echo "assert status=\"${1}\";\n";

