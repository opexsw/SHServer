#!/bin/bash
 # @name Notify serf EventHandler
 # @description Script to notify serf event handler to execute script and on particular node.
 # @author Zeeshan

/usr/local/bin/serf event -coalesce=false ${1} ${2}
